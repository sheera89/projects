/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WorkoutTrackingSystem;
import java.sql.*;
import java.io.*;
/**
 *
 * @author sheera
 */
public class WorkoutTrainingSystem{
//    public static void main(String[] args) throws SQLException, FileNotFoundException{
//        DatabaseManager dm = new DatabaseManager();
//
//        Connection connection = dm.getAdminConnection();
//        Statement s = connection.createStatement();
//        ResultSet set = s.executeQuery("select * from users;");
//        while(set.next()){
//            System.out.println(set.getString(3));
//        }
//        dm.closeConnection();
//    }
}